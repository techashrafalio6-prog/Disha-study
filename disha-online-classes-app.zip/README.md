# Disha Online Classes — Android App

Apna khud ka education app: courses → folders → videos / study material.
Backend: **Firebase Firestore** (no server code, free tier, console se data manage karo).

## 1. Firebase project banao (5 min)

1. https://console.firebase.google.com kholo → **Add project** → naam do (e.g. "Disha Online Classes")
2. Project ke andar **Build → Firestore Database** → **Create database** → test mode me start karo
3. **Project settings (gear icon) → Your apps → Add app → Android**
   - Package name: `com.aistudio.dishaonline.krvxqw` (yeh `app/build.gradle.kts` ke `applicationId` se match hona chahiye)
   - `google-services.json` file download karo
4. Us file ko project ke andar `app/google-services.json` path pe rakho (root folder mein nahi, `app` folder ke andar)

Bas — ab app tumhare Firestore se juda hua hai.

## 2. Firestore data structure

```
courses (collection)
  └── {courseId} (document)
        title: "Class 10 Science"
        description: "Full syllabus batch"
        thumbnailUrl: ""
        └── items (sub-collection)
              └── {itemId} (document)
                    type: "FOLDER" | "VIDEO" | "MATERIAL"
                    title: "Chapter 1: Light"
                    parentId: "root"        // ya kisi FOLDER item ki id
                    order: 1                // list mein sorting ke liye
                    videoUrl: ""            // sirf VIDEO ke liye (YouTube link ya direct mp4)
                    materialUrl: ""         // sirf MATERIAL ke liye (PDF ka direct link)

banners (collection)              -- home screen ke upar wala sliding banner
  └── {id} (document)
        imageUrl: "https://..."   // banner ki image ka direct link
        linkUrl: ""               // optional, abhi tap se kuch nahi khulta
        order: 1

social_links (collection)         -- "Social Links" screen
  └── {id} (document)
        label: "WhatsApp Group"
        url: "https://wa.me/..."
        order: 1
```

### Data kaise add karo (Firestore console se, bina code ke)

1. Firestore console mein **Start collection** → naam `courses`
2. Document add karo, ID auto ya custom, fields: `title`, `description`, `thumbnailUrl`
3. Us document ke andar **Start collection** → naam `items`
4. Har video/folder/material ke liye ek document, upar wali fields ke saath
5. Banner aur social links ke liye same tarike se `banners` aur `social_links` collections banao (course ke andar nahi, root level pe)

**Example — ek video item:**
```
type: VIDEO
title: "Chapter 1 - Intro Video"
parentId: root
order: 1
videoUrl: https://www.youtube.com/watch?v=XXXXXXXXXXX
```

**Example — ek folder aur uske andar video:**
```
Folder item:  type=FOLDER, title="Chapter 2", parentId=root, order=2   → id mil jayegi, e.g. "ch2"
Video item:   type=VIDEO, title="Ch2 Lecture 1", parentId=ch2, order=1, videoUrl=...
```

## 3. Run Locally

**Prerequisites:** [Android Studio](https://developer.android.com/studio)

1. Android Studio kholo → **Open** → is project ka folder select karo
2. `app/google-services.json` file daalna na bhoolna (step 1 dekho)
3. `app/build.gradle.kts` mein ye line hata do: `signingConfig = signingConfigs.getByName("debugConfig")`
4. Emulator ya phone pe **Run** karo

## App ka structure (agar aage khud kuch badalna ho)

- `data/Models.kt` — Course, ContentItem, BannerItem, SocialLink data classes
- `data/CourseRepository.kt` — Firestore se data fetch karta hai
- `data/ViewModels.kt` — UI state manage karta hai
- `data/UserPrefs.kt` — student ka naam phone mein hi save karta hai (pehli baar app khulne par poochta hai)
- `ui/screens/WelcomeNameScreen.kt` — pehli baar naam poochne wali screen
- `ui/screens/HomeScreen.kt` — greeting, banner slider, grid menu, courses list (jaisa design photo bheja tha)
- `ui/screens/CoursesScreen.kt` — sirf courses ki list
- `ui/screens/FolderScreen.kt` — folder ke andar folders/videos/materials
- `ui/screens/VideoPlayerScreen.kt` — video player (YouTube ya direct video links dono chalte hain)
- `ui/screens/MaterialScreen.kt` — PDF/study material viewer
- `ui/screens/SocialLinksScreen.kt` — social media links ki list
- `ui/screens/ComingSoonScreen.kt` — un grid buttons ke liye jo abhi functional nahi hain (Study Notes, NCERT Book, Test Series, Class Timetable) — inhe baad mein bana sakte hain jab chaho
- `ui/nav/AppNav.kt` — sab screens ko connect karta hai

## Home screen grid mein kya kaam karta hai, kya nahi

| Button | Status |
|---|---|
| Courses | ✅ Kaam karta hai — Firestore se courses dikhata hai |
| Social Links | ✅ Kaam karta hai — Firestore ke `social_links` se |
| Study Notes / NCERT Book / Test Series / Class Timetable | ⏳ "Coming soon" dikhata hai — inka koi backend nahi bana hai abhi |

**Paid/Free course ka alag distinction abhi nahi hai** — ye banane ke liye payment gateway (Razorpay wagera) integrate karna padega, jo alag kaam hai. Jab chaho batana, wo bhi bana denge.
