package com.example.data

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

/**
 * Talks to Firebase Firestore. See README.md for the exact schema and how to add data
 * from the Firebase console -- no server code needed.
 */
class CourseRepository {

    private val db = FirebaseFirestore.getInstance()

    suspend fun getCourses(): List<Course> {
        val snapshot = db.collection("courses").get().await()
        return snapshot.documents.map { doc ->
            Course(
                id = doc.id,
                title = doc.getString("title") ?: "",
                description = doc.getString("description") ?: "",
                thumbnailUrl = doc.getString("thumbnailUrl") ?: "",
            )
        }
    }

    suspend fun getItems(courseId: String, parentId: String): List<ContentItem> {
        val snapshot = db.collection("courses").document(courseId)
            .collection("items")
            .whereEqualTo("parentId", parentId)
            .get()
            .await()

        return snapshot.documents.map { doc ->
            val typeStr = doc.getString("type") ?: "FOLDER"
            ContentItem(
                id = doc.id,
                courseId = courseId,
                parentId = doc.getString("parentId") ?: "root",
                type = runCatching { ContentType.valueOf(typeStr) }.getOrDefault(ContentType.FOLDER),
                title = doc.getString("title") ?: "",
                order = (doc.getLong("order") ?: 0L).toInt(),
                videoUrl = doc.getString("videoUrl") ?: "",
                materialUrl = doc.getString("materialUrl") ?: "",
            )
        }.sortedBy { it.order }
    }
}
