package com.example.data

/**
 * A top-level course, e.g. "Class 10 Science Batch".
 * Stored in Firestore collection: courses/{courseId}
 */
data class Course(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val thumbnailUrl: String = "",
)

/**
 * One item inside a course: either a sub-folder, a video, or a study material (PDF/notes).
 * Stored in Firestore collection: courses/{courseId}/items/{itemId}
 * Root-level items have parentId == "root". Items inside a folder have parentId == that folder's id.
 */
data class ContentItem(
    val id: String = "",
    val courseId: String = "",
    val parentId: String = "root",
    val type: ContentType = ContentType.FOLDER,
    val title: String = "",
    val order: Int = 0,
    // Used when type == VIDEO. Can be a direct video URL (mp4/HLS) or a YouTube watch URL.
    val videoUrl: String = "",
    // Used when type == MATERIAL. Direct link to a PDF file.
    val materialUrl: String = "",
)

enum class ContentType {
    FOLDER, VIDEO, MATERIAL
}

/** A slide in the home-screen banner carousel. Stored in Firestore collection: banners/{id} */
data class BannerItem(
    val id: String = "",
    val imageUrl: String = "",
    val linkUrl: String = "",
    val order: Int = 0,
)

/** A social media link shown on the Social Links screen. Stored in: social_links/{id} */
data class SocialLink(
    val id: String = "",
    val label: String = "",
    val url: String = "",
    val order: Int = 0,
)

/** One entry in the home-screen grid menu. */
data class GridMenuItem(
    val title: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val destination: String,
)
