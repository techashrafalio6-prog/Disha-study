package com.example.data

/**
 * App branding — logo, home banners, social links.
 * Sirf yahan values badal ke sab jagah update ho jayega.
 */
object BrandConfig {

    const val APP_NAME = "Disha Online Classes"

    const val LOGO_URL = "https://files.catbox.moe/4tbsk3.jpg"

    val BANNER_URLS = listOf(
        "https://files.catbox.moe/pp491j.jpg",
        "https://files.catbox.moe/efpxiz.jpg",
    )

    val SOCIAL_LINKS = listOf(
        SocialLink(id = "youtube", label = "YouTube", url = "https://youtube.com/@ashraf_cyberx?si=Uw3PAMKLQG_O84zV", order = 1),
        SocialLink(id = "instagram", label = "Instagram", url = "https://www.instagram.com/ashraf_cyberx?stkn=aGEyNG5lZm5namFx", order = 2),
        SocialLink(id = "telegram", label = "Telegram Channel", url = "https://t.me/Ashraf_CyberX", order = 3),
        SocialLink(id = "whatsapp", label = "WhatsApp", url = "https://wa.me/919297907815", order = 4),
    )
}
