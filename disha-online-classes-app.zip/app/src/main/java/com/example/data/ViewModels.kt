package com.example.data

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class UiState<out T> {
    object Loading : UiState<Nothing>()
    data class Success<T>(val data: T) : UiState<T>()
    data class Error(val message: String) : UiState<Nothing>()
}

class CoursesViewModel(
    private val repository: CourseRepository = CourseRepository()
) : ViewModel() {

    private val _state = MutableStateFlow<UiState<List<Course>>>(UiState.Loading)
    val state: StateFlow<UiState<List<Course>>> = _state.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _state.value = UiState.Loading
            _state.value = try {
                UiState.Success(repository.getCourses())
            } catch (e: Exception) {
                UiState.Error(e.message ?: "Kuch galat ho gaya")
            }
        }
    }
}

class FolderViewModel(
    private val courseId: String,
    private val parentId: String,
    private val repository: CourseRepository = CourseRepository()
) : ViewModel() {

    private val _state = MutableStateFlow<UiState<List<ContentItem>>>(UiState.Loading)
    val state: StateFlow<UiState<List<ContentItem>>> = _state.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _state.value = UiState.Loading
            _state.value = try {
                UiState.Success(repository.getItems(courseId, parentId))
            } catch (e: Exception) {
                UiState.Error(e.message ?: "Kuch galat ho gaya")
            }
        }
    }
}

class HomeViewModel(
    private val repository: CourseRepository = CourseRepository()
) : ViewModel() {

    private val _state = MutableStateFlow<UiState<List<Course>>>(UiState.Loading)
    val state: StateFlow<UiState<List<Course>>> = _state.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _state.value = UiState.Loading
            _state.value = try {
                UiState.Success(repository.getCourses())
            } catch (e: Exception) {
                UiState.Error(e.message ?: "Kuch galat ho gaya")
            }
        }
    }
}
