package com.example.data

import android.content.Context

/** Stores the student's display name locally on the device (no login/account needed). */
object UserPrefs {
    private const val PREFS = "disha_prefs"
    private const val KEY_NAME = "student_name"

    fun getName(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString(KEY_NAME, null)
    }

    fun saveName(context: Context, name: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_NAME, name).apply()
    }
}
