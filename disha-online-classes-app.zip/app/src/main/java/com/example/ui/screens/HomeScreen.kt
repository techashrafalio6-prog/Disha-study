package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.data.BrandConfig
import com.example.data.Course
import com.example.data.HomeViewModel
import com.example.data.UiState
import com.example.data.UserPrefs
import kotlinx.coroutines.delay

private data class MenuTile(val title: String, val icon: ImageVector, val route: String)

private val menuTiles = listOf(
    MenuTile("Courses", Icons.Filled.School, "courses"),
    MenuTile("Study Notes", Icons.Filled.MenuBook, "coming_soon/Study Notes"),
    MenuTile("NCERT Book", Icons.Filled.ImportContacts, "coming_soon/NCERT Book"),
    MenuTile("Test Series", Icons.Filled.Quiz, "coming_soon/Test Series"),
    MenuTile("Class Timetable", Icons.Filled.CalendarMonth, "coming_soon/Class Timetable"),
    MenuTile("Social Links", Icons.Filled.Share, "social_links"),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpenCourse: (Course) -> Unit,
    onOpenAllCourses: () -> Unit,
    onOpenSocialLinks: () -> Unit,
    onOpenComingSoon: (String) -> Unit,
    viewModel: HomeViewModel = viewModel(),
) {
    val context = LocalContext.current
    val name = remember { UserPrefs.getName(context) ?: "Student" }
    val state by viewModel.state.collectAsState()

    val onTileClick: (String) -> Unit = { route ->
        when {
            route == "courses" -> onOpenAllCourses()
            route == "social_links" -> onOpenSocialLinks()
            route.startsWith("coming_soon/") -> onOpenComingSoon(route.removePrefix("coming_soon/"))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(
                            model = BrandConfig.LOGO_URL,
                            contentDescription = "Logo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape),
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(BrandConfig.APP_NAME, fontWeight = FontWeight.SemiBold)
                    }
                },
                actions = {
                    IconButton(onClick = { }) {
                        Icon(Icons.Filled.Notifications, contentDescription = "Notifications")
                    }
                }
            )
        }
    ) { padding ->
        when (val s = state) {
            is UiState.Loading -> CenteredMessage("Loading...")
            is UiState.Error -> CenteredMessage("Error: ${s.message}", onRetry = viewModel::load)
            is UiState.Success -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(bottom = 24.dp),
                ) {
                    item {
                        Text(
                            "Hello, $name",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        )
                    }
                    item { BannerCarousel(BrandConfig.BANNER_URLS) }
                    item {
                        Spacer(modifier = Modifier.height(16.dp))
                        MenuGrid(onTileClick = onTileClick)
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                    item {
                        Text(
                            "Courses",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        )
                    }
                    if (s.data.isEmpty()) {
                        item {
                            Text(
                                "Abhi koi course nahi hai. Firebase console se add karo.",
                                modifier = Modifier.padding(16.dp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    } else {
                        items(s.data) { course ->
                            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                                HomeCourseCard(course) { onOpenCourse(course) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BannerCarousel(bannerUrls: List<String>) {
    if (bannerUrls.isEmpty()) return

    val pagerState = rememberPagerState(pageCount = { bannerUrls.size })

    LaunchedEffect(pagerState, bannerUrls.size) {
        while (true) {
            delay(3500)
            val next = (pagerState.currentPage + 1) % bannerUrls.size
            pagerState.animateScrollToPage(next)
        }
    }

    Column {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .height(150.dp),
        ) { page ->
            AsyncImage(
                model = bannerUrls[page],
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(16.dp)),
            )
        }
        if (bannerUrls.size > 1) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                repeat(bannerUrls.size) { index ->
                    val active = index == pagerState.currentPage
                    Box(
                        modifier = Modifier
                            .padding(2.dp)
                            .size(if (active) 8.dp else 6.dp)
                            .clip(RoundedCornerShape(50))
                            .background(
                                if (active) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outlineVariant
                            )
                    )
                }
            }
        }
    }
}

@Composable
private fun MenuGrid(onTileClick: (String) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 240.dp)
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(menuTiles) { tile ->
            Card(
                onClick = { onTileClick(tile.route) },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.aspectRatio(1f),
            ) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Icon(
                        tile.icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp),
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        tile.title,
                        style = MaterialTheme.typography.labelMedium,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        maxLines = 2,
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeCourseCard(course: Course, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(course.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                if (course.description.isNotBlank()) {
                    Text(
                        course.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
