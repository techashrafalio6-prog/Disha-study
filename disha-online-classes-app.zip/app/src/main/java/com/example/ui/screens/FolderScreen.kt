package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.compose.viewModelFactory
import androidx.lifecycle.viewmodel.initializer
import com.example.data.ContentItem
import com.example.data.ContentType
import com.example.data.FolderViewModel
import com.example.data.UiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FolderScreen(
    courseId: String,
    parentId: String,
    title: String,
    onBack: () -> Unit,
    onOpenFolder: (ContentItem) -> Unit,
    onOpenVideo: (ContentItem) -> Unit,
    onOpenMaterial: (ContentItem) -> Unit,
) {
    val viewModel: FolderViewModel = viewModel(
        factory = viewModelFactory {
            initializer { FolderViewModel(courseId, parentId) }
        }
    )
    val state by viewModel.state.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (val s = state) {
                is UiState.Loading -> CenteredMessage("Loading...")
                is UiState.Error -> CenteredMessage("Error: ${s.message}", onRetry = viewModel::load)
                is UiState.Success -> {
                    if (s.data.isEmpty()) {
                        CenteredMessage("Ye folder khaali hai.")
                    } else {
                        LazyColumn(contentPadding = PaddingValues(12.dp)) {
                            items(s.data) { item ->
                                ContentRow(item) {
                                    when (item.type) {
                                        ContentType.FOLDER -> onOpenFolder(item)
                                        ContentType.VIDEO -> onOpenVideo(item)
                                        ContentType.MATERIAL -> onOpenMaterial(item)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ContentRow(item: ContentItem, onClick: () -> Unit) {
    val icon = when (item.type) {
        ContentType.FOLDER -> Icons.Filled.Folder
        ContentType.VIDEO -> Icons.Filled.PlayCircle
        ContentType.MATERIAL -> Icons.Filled.Description
    }
    Column {
        ListItem(
            headlineContent = { Text(item.title) },
            leadingContent = { Icon(icon, contentDescription = null) },
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick),
        )
        HorizontalDivider()
    }
}
