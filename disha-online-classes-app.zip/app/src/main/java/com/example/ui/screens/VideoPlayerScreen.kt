package com.example.ui.screens

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/**
 * Plays a direct video URL (mp4/HLS) with ExoPlayer, or embeds a YouTube URL in a WebView
 * if the link points to youtube.com / youtu.be.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoPlayerScreen(
    title: String,
    videoUrl: String,
    onBack: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (videoUrl.contains("youtube.com") || videoUrl.contains("youtu.be")) {
                YouTubeEmbed(videoUrl)
            } else {
                ExoVideoPlayer(videoUrl)
            }
        }
    }
}

@Composable
private fun ExoVideoPlayer(videoUrl: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    AndroidView(
        modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f),
        factory = {
            val player = ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(videoUrl))
                prepare()
                playWhenReady = true
            }
            PlayerView(context).apply { this.player = player }
        }
    )
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun YouTubeEmbed(watchUrl: String) {
    val videoId = extractYouTubeId(watchUrl)
    val embedUrl = if (videoId != null) "https://www.youtube.com/embed/$videoId" else watchUrl
    AndroidView(
        modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f),
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                webViewClient = WebViewClient()
                loadUrl(embedUrl)
            }
        }
    )
}

private fun extractYouTubeId(url: String): String? {
    val patterns = listOf(
        Regex("v=([a-zA-Z0-9_-]{11})"),
        Regex("youtu\\.be/([a-zA-Z0-9_-]{11})"),
    )
    for (p in patterns) {
        p.find(url)?.groupValues?.get(1)?.let { return it }
    }
    return null
}
