package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light theme
val BluePrimary = Color(0xFF1E56A0)
val BlueSecondary = Color(0xFF3D7EBF)
val GoldAccent = Color(0xFFF5A623)

// Dark theme
val BluePrimaryDark = Color(0xFF9FC5E8)
val BlueSecondaryDark = Color(0xFF6FA8DC)
val GoldAccentDark = Color(0xFFFBBF24)
