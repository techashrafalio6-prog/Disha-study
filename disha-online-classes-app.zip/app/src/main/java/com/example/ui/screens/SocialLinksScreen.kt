package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.example.data.BrandConfig

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialLinksScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val links = BrandConfig.SOCIAL_LINKS.sortedBy { it.order }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Social Links") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp)) {
            items(links) { link ->
                ListItem(
                    headlineContent = { Text(link.label) },
                    leadingContent = { Icon(Icons.Filled.Link, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            runCatching {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link.url)))
                            }
                        },
                )
                HorizontalDivider()
            }
        }
    }
}
