package com.example.ui.nav

import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.UserPrefs
import com.example.ui.screens.CoursesScreen
import com.example.ui.screens.FolderScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MaterialScreen
import com.example.ui.screens.SocialLinksScreen
import com.example.ui.screens.VideoPlayerScreen
import com.example.ui.screens.WelcomeNameScreen
import java.net.URLDecoder
import java.net.URLEncoder

private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
private fun dec(s: String) = URLDecoder.decode(s, "UTF-8")

@Composable
fun AppNavHost() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val hasName = remember { UserPrefs.getName(context) != null }
    val startDestination = if (hasName) "home" else "welcome"

    NavHost(navController = navController, startDestination = startDestination) {

        composable("welcome") {
            WelcomeNameScreen(onNameSaved = { name ->
                UserPrefs.saveName(context, name)
                navController.navigate("home") { popUpTo("welcome") { inclusive = true } }
            })
        }

        composable("home") {
            HomeScreen(
                onOpenCourse = { course ->
                    navController.navigate("folder/${course.id}/root/${enc(course.title)}")
                },
                onOpenAllCourses = { navController.navigate("courses") },
                onOpenSocialLinks = { navController.navigate("social_links") },
            )
        }

        composable("courses") {
            CoursesScreen(onCourseClick = { course ->
                navController.navigate("folder/${course.id}/root/${enc(course.title)}")
            })
        }

        composable("social_links") {
            SocialLinksScreen(onBack = { navController.popBackStack() })
        }

        composable(
            route = "folder/{courseId}/{parentId}/{title}",
            arguments = listOf(
                navArgument("courseId") { type = NavType.StringType },
                navArgument("parentId") { type = NavType.StringType },
                navArgument("title") { type = NavType.StringType },
            )
        ) { backStackEntry ->
            val courseId = backStackEntry.arguments?.getString("courseId") ?: ""
            val parentId = backStackEntry.arguments?.getString("parentId") ?: "root"
            val title = dec(backStackEntry.arguments?.getString("title") ?: "")

            FolderScreen(
                courseId = courseId,
                parentId = parentId,
                title = title,
                onBack = { navController.popBackStack() },
                onOpenFolder = { item ->
                    navController.navigate("folder/$courseId/${item.id}/${enc(item.title)}")
                },
                onOpenVideo = { item ->
                    navController.navigate("video/${enc(item.title)}/${enc(item.videoUrl)}")
                },
                onOpenMaterial = { item ->
                    navController.navigate("material/${enc(item.title)}/${enc(item.materialUrl)}")
                },
            )
        }

        composable(
            route = "video/{title}/{url}",
            arguments = listOf(
                navArgument("title") { type = NavType.StringType },
                navArgument("url") { type = NavType.StringType },
            )
        ) { backStackEntry ->
            val title = dec(backStackEntry.arguments?.getString("title") ?: "")
            val url = dec(backStackEntry.arguments?.getString("url") ?: "")
            VideoPlayerScreen(title = title, videoUrl = url, onBack = { navController.popBackStack() })
        }

        composable(
            route = "material/{title}/{url}",
            arguments = listOf(
                navArgument("title") { type = NavType.StringType },
                navArgument("url") { type = NavType.StringType },
            )
        ) { backStackEntry ->
            val title = dec(backStackEntry.arguments?.getString("title") ?: "")
            val url = dec(backStackEntry.arguments?.getString("url") ?: "")
            MaterialScreen(title = title, materialUrl = url, onBack = { navController.popBackStack() })
        }
    }
}
